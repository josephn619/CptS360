#include "functions.h"

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;

extern char gpath[128];
extern char *name[64];
extern int n;

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, iblk;

/************* rmdirc.c file **************/

int myrm_child(MINODE *parent, char *name)
{
    DIR *dp, *prevdp, *lastdp;
    char *cp, *lastcp, buf[BLKSIZE], tmp[256], *startptr, *endptr;
    INODE *ip = &parent->INODE;

    for (int i = 0; i < 12; i++)
    {
        if (ip->i_block[i] != 0)
        {
            get_block(parent->dev, ip->i_block[i], buf);
            dp = (DIR *)buf;
            cp = buf;

            while (cp < buf + BLKSIZE)
            {
                strncpy(tmp, dp->name, dp->name_len);
                tmp[dp->name_len] = 0;

                if (!strcmp(tmp, name))
                {
                    if (cp == buf && cp + dp->rec_len == buf + BLKSIZE)
                    {
                        bdalloc(parent->dev, ip->i_block[i]);
                        ip->i_size -= BLKSIZE;

                        while (ip->i_block[i + 1] != 0 && i + 1 < 12)
                        {
                            i++;
                            get_block(parent->dev, ip->i_block[i], buf);
                            put_block(parent->dev, ip->i_block[i - 1], buf);
                        }
                    }

                    else if (cp + dp->rec_len == buf + BLKSIZE)
                    {
                        prevdp->rec_len += dp->rec_len;
                        put_block(parent->dev, ip->i_block[i], buf);
                    }

                    else
                    {
                        lastdp = (DIR *)buf;
                        lastcp = buf;

                        while (lastcp + lastdp->rec_len < buf + BLKSIZE)
                        {
                            lastcp += lastdp->rec_len;
                            lastdp = (DIR *)lastcp;
                        }

                        lastdp->rec_len += dp->rec_len;

                        startptr = cp + dp->rec_len;
                        endptr = buf + BLKSIZE;

                        memmove(cp, startptr, endptr - startptr);
                        put_block(parent->dev, ip->i_block[i], buf);
                    }

                    parent->dirty = 1;
                    iput(parent);
                    return 0;
                }

                prevdp = dp;
                cp += dp->rec_len;
                dp = (DIR *)cp;
            }
        }
    }
    printf("ERROR: child not found\n");
    return -1;
}

int my_rmdir(char *pathname)
{
    int ino = getino(pathname);

    if (ino == -1)
    {
        printf("ERROR: ino does not exist\n");
        return -1;
    }

    MINODE *mip = iget(dev, ino);

    if (!S_ISDIR(mip->INODE.i_mode))
    {
        printf("ERROR: node is not a directory\n");
        return -1;
    }

    if (!is_empty(mip))
    {
        printf("ERROR: Dir is not empty\n");
        return -1;
    }

    if (mip->refCount > 2)
    {
        printf("ERROR: node is busy, refcount > 2, refcount = %d\n", mip->refCount);
        return -1;
    }

    uint other = mip->INODE.i_mode & 0x7;
    uint group = (mip->INODE.i_mode & 0x38) >> 3;
    uint owner = (mip->INODE.i_mode & 0x1C0) >> 6;
    if (!mip->INODE.i_mode & 0x1FF)
    {
        printf("ERROR: no permission\n");
        return -1;
    }

    if (running->uid != mip->INODE.i_uid && running->uid != 0) 
    {
        printf("ERROR: uid mismatch, no permission\n");
        return -1;
    }

    for (int i = 0; i < 12; i++)
    {
        if (mip->INODE.i_block[i] == 0)
            continue;
        bdalloc(mip->dev, mip->INODE.i_block[i]);
    }
    idalloc(mip->dev, mip->ino);

    mip->dirty = 1;
    iput(mip);

    char cp1[256], cp2[256], *parent, *child;
    strcpy(cp1, pathname);
    strcpy(cp2, pathname);

    parent = dirname(cp1);
    child = basename(cp2);

    int pino = getino(parent);
    if (pino == -1)
    {
        printf("error finding parent inode, rmdir\n");
        return -1;
    }

    MINODE *pip = iget(mip->dev, pino);
    myrm_child(pip, child);

    pip->INODE.i_links_count--;
    pip->INODE.i_atime = time(0L);
    pip->INODE.i_ctime = time(0L);
    pip->dirty = 1;

    iput(pip);

    return 0;
}