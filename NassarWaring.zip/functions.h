#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "util.h"

/************ cd_ls_pwd.c ***********/
int cd(char *pathname);
int ls_file(MINODE *mip, char *name);
int ls_dir(MINODE *mip);
int ls(char *pathname);
char *pwd(MINODE *wd);
void rpwd(MINODE *wd);

/************** mkdir_creat.c *************/
int enter_name(MINODE *pip, int myino, char *myname);
int my_kmdir(MINODE *pmip, char *name);
int my_create_helper(MINODE *pmip,char *name);
int my_create(char *pathname);
int my_mkdir(char *pathname);

/************** rmdir.c *************/
int myrm_child(MINODE *parent, char *name);
int my_rmdir(char *pathname);

/************** link_unlink.c *************/
int link_helper(char *pathname, char *link_name);
int my_link(char *old, char *new);
int my_unlink(char *pathname);

/************** symlink.c *************/
int my_symlink(char *old, char *new);


#endif