#ifndef UTIL_H
#define UTIL_H

#include "type.h"

int init();
int mount_root();
int quit();

int get_block(int dev, int blk, char *buf);
int put_block(int dev, int blk, char *buf);
int tokenize(char *pathname);
MINODE *iget(int dev, int ino);
void iput(MINODE *mip);
int search(MINODE *mip, char *name);
int getino(char *pathname);

/************************* cd_lw_pwd.c *************************/
int findmyino(MINODE *mip, int *parent_ino);
int findmyname(MINODE *parent_minode, int my_ino, char *my_name);

/************************* mkdir_creat.c *************************/
int tst_bit(char *buf, int bit);
int set_bit(char *buf, int bit);
int ialloc(int dev);
int balloc(int dev);

/************************* rmdir.c *************************/
int clr_bit(char *buf, int bitnum);
int idalloc(int dev, int ino);
int bdalloc(int dev, int bno);
int is_empty(MINODE *mip);

/************************* link_unlink.c *************************/
int inode_truncate(MINODE *mip);


#endif