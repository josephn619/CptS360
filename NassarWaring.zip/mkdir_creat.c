#include "functions.h"

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;

extern char gpath[128];
extern char *name[64];
extern int n;

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, iblk;

/************* mkdir_creat.c file **************/

int enter_name(MINODE *pip, int myino, char *myname)
{
    char buf[BLKSIZE], *cp;
    int bno;
    INODE *ip;
    DIR *dp;

    int need_len = 4 * ((8 + strlen(myname) + 3) / 4);

    ip = &pip->INODE;

    for (int i = 0; i < 12; i++)
    {
        if (ip->i_block[i] == 0)
            break;

        bno = ip->i_block[i];
        get_block(pip->dev, ip->i_block[i], buf);
        dp = (DIR *)buf;
        cp = buf;

        while (cp + dp->rec_len < buf + BLKSIZE)
        {
            printf("%s\n", dp->name);
            cp += dp->rec_len;
            dp = (DIR *)cp;
        }

        int ideal_len = 4 * ((8 + dp->name_len + 3) / 4);
        int remainder = dp->rec_len - ideal_len;

        if (remainder >= need_len)
        {
            dp->rec_len = ideal_len;
            cp += dp->rec_len;
            dp = (DIR *)cp;

            dp->inode = myino;
            strcpy(dp->name, myname);
            dp->name_len = strlen(myname);
            dp->rec_len = remainder;
            put_block(dev, bno, buf);
            return 0;
        }
        else
        {
            ip->i_size = BLKSIZE;
            bno = balloc(dev);
            ip->i_block[i] = bno;
            pip->dirty = 1;

            get_block(dev, bno, buf);
            dp = (DIR *)buf;
            cp = buf;

            dp->name_len = strlen(myname);
            strcpy(dp->name, myname);
            dp->inode = myino;
            dp->rec_len = BLKSIZE;

            put_block(dev, bno, buf);
            return 1;
        }
    }
}

int mkdir_helper(MINODE *pmip, char *name)
{
    MINODE *mip;
    char buf[BLKSIZE], *cp;
    DIR *dp;

    int ino = ialloc(dev);
    int blk = balloc(dev);

    printf("ino: %d, blk: %d\n", ino, blk);

    mip = iget(dev, ino);

    INODE *ip = &mip->INODE;
    ip->i_mode = 0x41ED;
    ip->i_uid = running->uid;
    ip->i_gid = running->gid;
    ip->i_size = BLKSIZE;
    ip->i_links_count = 2;
    ip->i_atime = time(0L);
    ip->i_ctime = time(0L);
    ip->i_mtime = time(0L);
    ip->i_blocks = 2;
    ip->i_block[0] = blk;
    for (int i = 1; i < 15; i++)
        ip->i_block[i] = 0;

    mip->dirty = 1;
    iput(mip);

    get_block(dev, blk, buf);
    dp = (DIR *)buf;
    cp = buf;

    printf("Create . and .. in %s\n", name);

    dp->inode = ino;
    dp->rec_len = 12;  // 4 * [(8 + name_len + 3) / 4]
    dp->name_len = 1;
    dp->name[0] = '.';

    cp += dp->rec_len;
    dp = (DIR *)cp;

    dp->inode = pmip->ino;
    dp->rec_len = BLKSIZE - 12;
    dp->name_len = 2;
    dp->name[0] = '.';
    dp->name[1] = '.';

    put_block(dev, blk, buf); 

    enter_name(pmip, ino, name);

    return 0;
}

int my_mkdir(char *pathname)
{
    MINODE *begin;

    char parent_path[256], child_path[256];

    strcpy(parent_path,pathname);
    strcpy(child_path,pathname);

    if(pathname[0] == '/')
    {
        begin = root;
        dev = root->dev;
    }
    else
    {
        begin = running->cwd;
        dev = running->cwd->dev;
    }

    char *parent = dirname(parent_path);
    char *child = basename(child_path);

    int pino = getino(parent);

    MINODE *pmip = iget(dev,pino);

    if(!S_ISDIR(pmip->INODE.i_mode))
    {
        printf("Not a directory!\n");
        return -1;
    }

    if(search(pmip,child))
    {
        printf("child %s already exists under parent %s", child, parent);
        return -1;
    }

    mkdir_helper(pmip,child);

    pmip->INODE.i_links_count++;
    pmip->dirty = 1;
    iput(pmip);
    return 0;
}

int creat_helper(MINODE *pmip,char *name)
{
    DIR *dp;
    MINODE *mip;
    char *buf[BLKSIZE], *cp;

    int ino = ialloc(dev);
    int blk = balloc(dev);

    printf("ino: %d, blk: %d\n", ino, blk);

    mip = iget(dev, ino);

    INODE *ip = &mip->INODE;
    ip->i_mode = 0644;
    ip->i_uid = running->uid;
    ip->i_gid = running->gid;
    ip->i_size = 0;
    ip->i_links_count = 1;
    ip->i_atime = time(0L);
    ip->i_ctime = time(0L);
    ip->i_mtime = time(0L);
    ip->i_blocks = 2;
    ip->i_block[0] = 0;
    for (int i = 1; i < 15; i++)
        ip->i_block[i] = 0;

    mip->dirty = 1;
    iput(mip);

    enter_name(pmip, ino, name);

    return 0;
}

int my_creat(char *pathname)
{ 
    MINODE *begin;
    char parent_path[256], child_path[256];

    strcpy(parent_path,pathname);
    strcpy(child_path,pathname);

    if(pathname[0] == '/')
    {
        begin = root;
        dev = root->dev;
    }
    else
    {
        begin = running->cwd;
        dev = running->cwd->dev;
    }

    char *parent = dirname(parent_path);
    char *child = basename(child_path);

    int pino = getino(parent);

    MINODE *pmip = iget(dev,pino);

    if(!S_ISDIR(pmip->INODE.i_mode))
    {
        printf("Not a directory!\n");
        return -1;
    }

    if(search(pmip,child))
    {
        printf("child already exists\n");
        return -1;
    }

    creat_helper(pmip,child);

    pmip->dirty = 1;
    iput(pmip);
    return 0;
}