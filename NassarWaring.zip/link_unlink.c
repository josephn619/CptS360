#include "functions.h"

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;

extern char gpath[128];
extern char *name[64];
extern int n;

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, iblk;

/************* link_unlink.c file **************/

int link_helper(char *pathname, char *link_name)
{
    char parent[256], child[256];
    int oino, pino;
    oino = getino(pathname);
    MINODE *omip = iget(dev,oino);
    MINODE *pmip;

    if(pathname[0] == '/')
        dev = root->dev;
    else
        dev = running->cwd->dev;

    if (S_ISDIR(omip->INODE.i_mode)) 
    {
        printf("Directory. EXIT\n");
        return -1;
    }

    int newino = getino(link_name);

    if(newino != 0)
    {
        "Error Exit\n";
        return -1;
    }

    strcpy(child,basename(link_name));
    strcpy(parent,dirname(link_name));

    pino = getino(parent);
    pmip = iget(dev,pino);
    
    enter_name(pmip,oino,child);
    omip->INODE.i_links_count++;
    omip->dirty = 1;
    pmip->dirty = 1;
    iput(omip);
    iput(pmip);
}

int my_link(char *old, char *new)
{
    printf("old = %s\nnew = %s\n", old, new);
    link_helper(old, new);
}

int my_unlink(char *pathname) 
{
    int inode;
    MINODE *mip;

    if (pathname[0] == '/')
        dev = root->dev;
    else
        dev = running->cwd->dev;

    char parent[256], child[256];
    strcpy(parent, dirname(pathname));
    strcpy(child, basename(pathname));
    
    inode = getino(pathname);
    if (inode == -1) 
    {
        printf("error getting link inode\n");
        return -1;
    }
    mip = iget(dev, inode);

    if (S_ISDIR(mip->INODE.i_mode)) 
    {
        printf("dir cannot be link; cannot unlink %s\n", pathname);
        return -1;
    }

    uint other = mip->INODE.i_mode & 0x7;
    uint group = (mip->INODE.i_mode & 0x38) >> 3;
    uint owner = (mip->INODE.i_mode & 0x1C0) >> 6;
    if (!mip->INODE.i_mode & 0x1FF)
    {
        printf("ERROR: no permission\n");
        return -1;
    }

    if (running->uid != mip->INODE.i_uid && running->uid != 0) 
    {
        printf("ERROR: uid mismatch, no permission\n");
        return -1;
    }

    mip->INODE.i_links_count--;
    if (mip->INODE.i_links_count == 0)
        if (!S_ISLNK(mip->INODE.i_mode))
            inode_truncate(mip);
    mip->dirty = 1;
    iput(mip);

    int pino = getino(parent);
    if (pino == -1) {
        printf("error getting parent ino (link)\n");
        return -1;
    }
    MINODE *pip = iget(mip->dev, pino);
    myrm_child(pip, child);
}