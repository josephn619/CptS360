#include "functions.h"

/**** globals defined in main.c file ****/
extern MINODE minode[NMINODE];
extern MINODE *root;
extern PROC   proc[NPROC], *running;

extern char gpath[128];
extern char *name[64];
extern int n;

extern int fd, dev;
extern int nblocks, ninodes, bmap, imap, iblk;

/************* symlink.c file **************/

int my_symlink(char *old, char *new)
{
    MINODE *mip;

    if (old[0] == '/')
        dev = root->dev;
    else
        dev = running->cwd->dev;

    int old_ino = getino(old);
    if (old_ino == -1)
    {
        printf("%s does not exist\n", old);
        return -1;
    }

    if (new[0] == '/')
        dev = root->dev;
    else
        dev = running->cwd->dev;

    my_creat(new);

    int new_ino = getino(new);
    if (new_ino == -1) 
    {
        printf("%s does not exist\n", new);
        return -1;
    }
    mip = iget(dev, new_ino);
    mip->INODE.i_mode = 0xA1FF;
    mip->dirty = 1;

    strncpy(mip->INODE.i_block, old, 84);

    mip->INODE.i_size = strlen(old) + 1;

    mip->dirty = 1;
    iput(mip);
}