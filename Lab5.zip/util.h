#ifndef HEADER_H
#define HEADER_H

#include "type.h"

int init();
int mount_root();
int quit();

int get_block(int dev, int blk, char *buf);
int put_block(int dev, int blk, char *buf);
int tokenize(char *pathname);
MINODE *iget(int dev, int ino);
void iput(MINODE *mip);
int search(MINODE *mip, char *name);
int findmyino(MINODE *mip, int *parent_ino);
int findmyname(MINODE *parent_minode, int my_ino, char *my_name);
int getino(char *pathname);

#endif