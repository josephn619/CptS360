#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "util.h"

int cd(char *pathname);
int ls_file(MINODE *mip, char *name);
int ls_dir(MINODE *mip);
int ls(char *pathname);
char *pwd(MINODE *wd);

#endif