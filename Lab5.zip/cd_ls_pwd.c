#include "functions.h"

/************* cd_ls_pwd.c file **************/
int cd(char *pathname)
{
  printf("cd %s\n", pathname);

  int ino = getino(pathname);
  if (ino == -1)
  {
    printf("Error: ino not found.\n");
    return 0;
  }

  MINODE *mip = iget(dev, ino);

  if (!S_ISDIR(mip->INODE.i_mode))
  {
    printf("Error: mip not found.");
    return 0;
  }

  iput(running->cwd);
  running->cwd = mip;
  return 1;
}

int ls_file(MINODE *mip, char *name)
{
    char *t1 = "xwrxwrxwr-------";
    char *t2 = "----------------";

    u16 i_mode = mip->INODE.i_mode;
    char ftime[264];
  
    // printing the details of the file
    if ((i_mode & 0xF000) == 0x8000) // if (S_ISREG())
        printf("%c", '-');
    if ((i_mode & 0xF000) == 0x4000) // if (S_ISDIR())
        printf("%c", 'd');
    if ((i_mode & 0xF000) == 0xA000) // if (S_ISLNK())
        printf("%c", 'l');
    for (int i = 8; i >= 0; i--)
    {
        if (i_mode & (1 << i))
            printf("%c", t1[i]); // print r|w|x 
        else
            printf("%c", t2[i]); // or print -
    }
    printf("%4d ", mip->INODE.i_links_count); // link count
    printf("%4d ", mip->INODE.i_gid);   // gid
    printf("%4d ", mip->INODE.i_uid);   // uid
    printf("%8ld ", mip->INODE.i_size);  // file size

    strcpy(ftime, ctime((time_t *)&(mip->INODE.i_mtime))); // print time in calendar form ftime[strlen(ftime)-1] = 0; // kill \n at end
    ftime[strlen(ftime) - 1] = 0;        // removes the \n
    printf("%s ", ftime);                // prints the time

    printf("%s",name);

    printf("\n");
    return 0;
}

int ls_dir(MINODE *mip)
{
  char buf[BLKSIZE], temp[256];
  DIR *dp;
  char *cp;
  MINODE *tmip;

  get_block(dev, mip->INODE.i_block[0], buf);
  dp = (DIR *)buf;
  cp = buf;

  while (cp < buf + BLKSIZE)
  {
     strncpy(temp, dp->name, dp->name_len);
     temp[dp->name_len] = 0;

     tmip = iget(dev,dp->inode);
     ls_file(tmip,temp);
     
     cp += dp->rec_len;
     dp = (DIR *)cp;
  }
  printf("\n");
  return 0;
}

int ls(char *pathname)
{
  int type;
  MINODE *mip;
  int temp_ino;
  if(strcmp(pathname,"") == 0)
    ls_dir(running->cwd);
  else
  {
    temp_ino = getino(pathname);
    dev = root->dev;
    mip = iget(dev,temp_ino);
    type = mip->INODE.i_mode;
    // Checking to see if it is a directory or a file
     if ((type & 0xF000) == 0x4000) // if (S_ISDIR())
       ls_dir(mip);
     else
       ls_file(mip,basename(pathname));
  }
}

char *pwd(MINODE *cwd)
{
  if (cwd == root)
    printf("pwd = /\n");
  else
  {
    printf("cwd = ");
    rpwd(cwd);
    printf("\n");
  }
}

void rpwd(MINODE *wd)
{
  if(wd == root)
    return;

  MINODE *pip;
  int ino, parentino;
  char buffer[BLKSIZE], name_cd[240];

  get_block(dev,wd->INODE.i_block[0],buffer);
  parentino = findmyino(wd,&ino);
  pip = iget(dev,parentino);

  findmyname(pip,ino,name_cd);
  rpwd(pip);

  printf("/%s",name_cd);
  return;
}
